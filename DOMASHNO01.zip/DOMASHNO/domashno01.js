var a = 119.95;
var b = 30;
var price = (b * a);
console.log(`${b} phones are ${price} $`);
var tax = 0.05;
var pricetax = price * tax;
console.log (`Price with tax ${pricetax}$`);
finallyprice = pricetax + price;
console.log(`The finally price is ${finallyprice}$`);
